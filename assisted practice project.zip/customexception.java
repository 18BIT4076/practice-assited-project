package Exception;
public class customexception{
        public static void main(String[] args)
        {

            int a=10,b=5,CS;

            try
            {
                if(b==0)        
                    throw(new ArithmeticException("Can't divide by zero."));
                else
                {
                    CS= a / b;
                    System.out.print("\n\tResult is : " + CS);
                }
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\n\tError : " + Ex.getMessage());
            }

            System.out.print("\n\tEnd of program.");
        }
    }
