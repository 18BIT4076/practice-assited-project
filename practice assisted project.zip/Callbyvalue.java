package methods;

public class Callbyvalue {

	int num=50;

	void operation(int num) {
		this.num=num*20/200;
		
	}
	public static void main(String[] args) {
		
		Callbyvalue obj= new Callbyvalue();
		
		System.out.println("Value of num before function call: "+obj.num);
		
		obj.operation(100);
		System.out.println("Value of num after function call: "+obj.num);
	}
}