package arrays;
public class arrayimpliment{

public static void main(String[] args) {
		int array[][]= {{3,2,1},{6,5,4},{9,8,7}};
		
		System.out.println("First element : "+array[0][0]);
		System.out.println("Second element: "+array[0][1]);
		System.out.println("Third element : "+array[0][2]);
		
		for (int row=0; row<3; row++) {
			
			for(int col=0;col<3;col++) {
				
				System.out.print(array[row][col]+"\t");
			}
			System.out.println();
			
		}
	}

}