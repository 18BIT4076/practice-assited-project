package constructors;

public class constructor {
	int empId;
	String empName;
	String role;
	float salary;
	
	public constructor() {
		empId=30;
		empName="Emp300";
		role="associate software engineer";
		salary=29000;
	}
	
	public constructor(int empId,String empName,String role,float salary) {
		this.empId=empId;
		this.empName=empName;
		this.role=role;
		this.salary=salary;
	}
	
	public void display() {
		System.out.println("Id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("role: "+role);
		System.out.println("Salary: "+salary);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		constructor e= new constructor();
		constructor e1= new constructor(15, "santhosh", "associate software enginner", 29000); 

		e.display();
		e1.display();
		
		 
	
	}

	
}