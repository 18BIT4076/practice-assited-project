package map;

import java.util.HashMap;
import java.util.TreeMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;

public class hashmap {
	
		public static void main(String[] args) {
			
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"santhosh");    
		      hm.put(2,"varun");    
		      hm.put(3,"mahi");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for (Iterator<Entry<Integer, String>> iterator = hm.entrySet().iterator(); iterator.hasNext();) {
				Entry<Integer, String> m = iterator.next();
				System.out.println(m.getKey()+" "+m.getValue());
			}
		    Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"kanna");  
		      ht.put(5,"gutty");  
		      ht.put(6,"tommy");  
		      ht.put(7,"jerry");  

		      System.out.println("\nThe elements of Table are ");  
		      for (Iterator<Entry<Integer, String>> iterator = ht.entrySet().iterator(); iterator.hasNext();) {
				Entry<Integer, String> n = iterator.next();
				System.out.println(n.getKey()+" "+n.getValue());
			}
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"sankar");    
		      map.put(9,"shenbagam");    
		      map.put(10,"rudra");       
		      
		      System.out.println("\nThe elements of Map are ");  
		      for (Iterator<Entry<Integer, String>> iterator = map.entrySet().iterator(); iterator.hasNext();) {
				Entry<Integer, String> l = iterator.next();
				System.out.println(l.getKey()+" "+l.getValue());
			}    
		      
		   }  
	}